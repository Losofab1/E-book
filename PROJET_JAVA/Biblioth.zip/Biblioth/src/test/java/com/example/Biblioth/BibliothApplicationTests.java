package com.example.Biblioth;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BibliothApplicationTests {

	@Test
	void contextLoads() {
	}

}
